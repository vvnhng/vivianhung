---
layout: post
category : lessons
tagline: "Using heliumjk.github.io"
tags : [bootstrap 4, web desing, jekyll]
img : helium-jekyll.jpg
img-mobile : 
img2 : 
img3 : 
author : Antonio Trento
title2 : Improve the desing of your blog
title3 : Make it a full of slides
css: 
js: 
bgcolor: ff5a71
keywords: helium, web desing, css, html, bootstrap 4
canonical: https://fullit.github.io
---
{% include JB/setup %}

Jekyll can give you the possibility to make awesome websites in minutes.
<!--more-->
That are **more faster than major other sites in the world** 

## How you can make an Amazing Website?

Use this template to generate a great jekyll website via a full of slide system make by fullpage.js and build quick your pages using the last version of Bootstrap 4.

