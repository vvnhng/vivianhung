
    $(document).ready(function() {
      //MixitUp
      $(function() {
        $('#portfolio').mixItUp();
      });
    });

